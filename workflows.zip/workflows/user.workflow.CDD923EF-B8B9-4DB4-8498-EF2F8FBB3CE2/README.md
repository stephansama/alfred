# Alfred Next.js Docs
> Quick access to Next.js docs site


## Installation
1. download latest version from [releases](https://github.com/skydiver/alfred-nextjs-docs/releaseses) section
2. open download `.alfredworkflow` file

## Usage
1. activate Alfred
2. type `njs <query>`

## Screenshot
![Workflow Screenshot](screenshot.png)
